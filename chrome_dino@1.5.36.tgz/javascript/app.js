'use strict';

const mgu = require('./kit/mgu');
const { Recorder } = require('./kit/record');
const Parked = require('./kit/parked');
const { Game } = require('./src/game');
const { migrateDifficulty } = require('./src/difficulty');
const { drawDashboard, WORLD_ASPECT } = require('./src/dashboard');
const { RankingCache }=require('./src/ranking-cache');
const keyboard=require('./src/name-keyboard');
const recoveryUI=require('./src/recovery');
const { Outbox }=require('./src/outbox');
const { Leaderboard, MODES, identity } = require('./src/leaderboard');
const { Controls } = require('./src/input');
const APP_VERSION = require('./kit/app-spec.json').version;
const i18n = require('./src/i18n');
const { Diag } = require('./kit/diag');
const { findVin } = require('./src/vin');
const { checkUpdate } = require('./src/update');

const W = 1600, H = 520, STEP = 1 / 120, SPEED_TTL = 5000;

mgu.run({
    start(ctx) {
        const { ui, log, settings } = ctx;
        const game = new Game();
        const migrated=migrateDifficulty(settings);
        game.setDifficulty(migrated.index);
        const bestKeys=migrated.bestKeys,bestModes=migrated.bestModes;
        let best=bestModes[game.difficulty];
        game.resize(WORLD_ASPECT);
        let languageChoice=settings.get('language')||'auto';
        const languageChoices=['auto','ru','en','de','fr','es','it','pt','nl','pl','uk','zh','ja'];
        if (languageChoices.indexOf(languageChoice)<0) languageChoice='auto';
        let systemLanguage=i18n.detect(ctx);
        let headLanguageRaw='';
        let headLanguageState='waiting';
        let headLanguageSource='not yet received';
        
        let updateState={available:false,latest:null,checked:false};
        function language(){return languageChoice==='auto'?systemLanguage:languageChoice;}
        function t(){return i18n.words(language());}
        let speedAt = -Infinity, speedValid = false;
        let going = false, closed = false, last = null, accumulator = 0, frameAt = -Infinity;
        let screenRecorder = null;
        const rankingClient=new Leaderboard('https://chrome-dino-leaderboard-staging.mguapps.workers.dev');
        const outbox=new Outbox(ctx.dataDir,rankingClient);
        const rankCache=new RankingCache(ctx.dataDir,rankingClient);
        let rankingData=null,editName=false,nameDraft='',nameCursor=0,namePos=0,nameShift=false,nameTilt=null;
        let nameKeys=keyboard.layout.slice();
        function nameSuggestions(values){nameKeys=keyboard.layout.slice();(values||[]).filter(n=>typeof n==='string'&&/^[A-Za-z0-9_-]{3,16}$/.test(n)).slice(0,5).forEach((n,i)=>nameKeys.push({id:'SUGGEST'+i,label:n,x:245+i*136,y:405,w:132,h:35,row:5}));if(nameCursor>=nameKeys.length)nameCursor=0;}
        let nameCheck='idle',nameCheckSeq=0,nameCheckAt=0,checkedName='';
        function checkName(){nameSuggestions([]);const n=nameDraft,seq=++nameCheckSeq;checkedName='';nameCheck=/^[A-Za-z0-9_-]{3,16}$/.test(n)?'checking':'invalid';nameCheckAt=Date.now()+350;if(nameCheck==='invalid')return;}
        function tickName(){if(onboardEditing&&!outbox.status().enabled){if(editName&&nameCheck==='checking')nameCheck='offline';return;}if(!editName||nameCheck!=='checking'||Date.now()<nameCheckAt)return;nameCheckAt=Infinity;const seq=nameCheckSeq,n=nameDraft;rankingClient.available(n,outbox.token(),(err,j)=>{if(seq!==nameCheckSeq||!editName||n!==nameDraft)return;nameCheck=err||!j?'offline':j.available?'free':'taken';checkedName=n;if(!err&&j&&!j.available)nameSuggestions(j.suggestions);});}
        let onboarding=Number(settings.get('onboardingSchema'))===1?0:1,onboardName=String(settings.get('offlineNickname')||''),onboardConsent=false,onboardEditing=false;
        let consentOpen=false,deleteOpen=false,consentEpoch=0,recovery=null,recoveryTilt=null;
        let rankingOpen=false, rankingMode=game.difficulty, rankingRows=[], rankingStatus='loading', rankingRequest=0, rankingError='';
        let selectedControl='play', paused=false, settingsOpen=false, dropdown=null, dropdownIndex=0, exitDialog=false, exiting=false, tiltHeld=false, rendererTiltAt=-Infinity;
        if(onboarding)selectedControl='onNext';
        let rotaryPosition=null,rendererRotaryAt=-Infinity;
        let fpsAt=0,fpsFrames=0,actualFPS=0;

        // Parked.watch exposes speed(), but treats unknown as parked and permits <=3 km/h.
        // Observe its real polling callback to reject invalid, unknown and stale data too.
        const safetyCtx = Object.assign({}, ctx, {
            signals: {
                watch(service, instance, callbacks, logger, options) {
                    const original = callbacks.statusCarSpeed2;
                    const wrapped = Object.assign({}, callbacks, {
                        statusCarSpeed2(value) {
                            const k = value && value.speedVehicleCentreOfGravity;
                            speedValid = typeof k === 'number' && isFinite(k) && k >= 0 && k < 65535;
                            speedAt = Date.now();
                            original(value);
                            sync();
                        },
                    });
                    return ctx.signals.watch(service, instance, wrapped, logger, options);
                },
            },
        });
        let parked = null;
        const ctl = new Controls(() => {
            sync();
            if(!going)return;
            if(exitDialog){exitAction(selectedControl);return;}
            if(paused){pauseAction(selectedControl);return;}
            if(recovery){recoveryAction(selectedControl);return;}
            if(editName){nameKey(nameCursor);return;}
            if(onboarding){onboardAction(selectedControl);return;}
            if(deleteOpen){if(selectedControl==='deleteYes')confirmDelete();else deleteOpen=false;return;}
            if(consentOpen){if(selectedControl==='consentYes')enableSync();else closeConsent();return;}
            if(rankingOpen){if(selectedControl==='deleteAccount')openDelete();else if(selectedControl==='recoveryCode')showRecoveryCode();else if(selectedControl==='editName')openName();else if(selectedControl==='syncProfile')openConsent();else if(/^rankTab[0-3]$/.test(selectedControl))selectRankTab(Number(selectedControl.slice(-1)));else if(selectedControl==='refresh')loadRanking(rankingMode,true);else closeRanking();return;}
            if(selectedControl==='ranking'&&game.state!=='playing'){openRanking();return;}
            if(settingsOpen){if(dropdown)commitDropdown(dropdownIndex);else if(selectedControl==='mode'||selectedControl==='language')openDropdown(selectedControl);else closeSettings();return;}
            if(selectedControl==='settings'&&game.state!=='playing'){openSettings();return;}
            if(game.state==='over'&&selectedControl==='overMenu'){returnToStart();return;}
            if(game.state==='playing'||selectedControl==='play')game.action();
        });
        function safe() {
            return parked && speedValid && Date.now() - speedAt <= SPEED_TTL && parked.speed() === 0;
        }
        function shown() { return ui.isVisible('GAME') && (!ui.hasFocus || ui.hasFocus('GAME')); }
        function saveBest() {
            if (game.score > best) {
                best=game.score;
                bestModes[game.difficulty]=best;
                settings.set(bestKeys[game.difficulty],best);
                settings.set('best',Math.max.apply(null,bestModes));
            }
        }
        function pauseRun() {
            if(game.state==='playing'&&!paused){paused=true;selectedControl='resume';saveBest();}
            last=null;accumulator=0;
        }
        function returnToStart(){saveBest();game.reset();paused=false;selectedControl='play';last=null;accumulator=0;}
        function pauseAction(choice){
            if(!paused||!going||!safe())return;
            if(choice==='menu'){returnToStart();return;}
            else if(choice!=='resume')return;
            paused=false;selectedControl='play';last=null;accumulator=0;
        }
        function onboardStep(n){onboarding=n;selectedControl='onNext';}
        function onboardAction(action){if(!going||!safe()||!onboarding)return;if(action==='onBack'){++consentEpoch;onboardStep(Math.max(1,onboarding-1));return;}
            if(onboarding===1){onboardStep(2);return;}
            if(onboarding===2){if(action==='onEdit'){onboardEditing=true;editName=true;nameDraft=onboardName||outbox.status().nickname||'';namePos=nameDraft.length;nameCursor=0;nameShift=false;nameTilt=null;checkName();return;}onboardStep(3);return;}
            if(onboarding===3){if(outbox.status().enabled){onboardStep(4);return;}onboardConsent=action==='onNext';if(onboardConsent){openRecovery(true);return;}++consentEpoch;onboardStep(4);return;}
            if(onboarding===4){if(outbox.status().enabled&&onboardName&&onboardName!==outbox.status().nickname)outbox.rename(onboardName,bestModes);if(onboardName)settings.set('offlineNickname',onboardName);settings.set('onboardingSchema',1);onboarding=0;selectedControl='play';}
        }
        function onboardControls(){return onboarding===1?['onNext']:onboarding===2?['onEdit','onBack','onNext']:onboarding===3?(outbox.status().enabled?['onBack','onNext']:['onBack','onSkip','onNext']):['onBack','onNext'];}
        function openConsent(){if(outbox.status().enabled||outbox.status().deleting)return;if(outbox.status().recoveryPending){openRecovery(false);return;}consentOpen=true;selectedControl='consentNo';}
        function closeConsent(){++consentEpoch;consentOpen=false;selectedControl='syncProfile';}
        function enableSync(){openRecovery(false);}
        function openDelete(){if(!outbox.status().enabled||outbox.status().deleting)return;deleteOpen=true;selectedControl='deleteNo';}
        function confirmDelete(){if(!going||!safe())return;if(outbox.erase()){deleteOpen=false;settings.set('offlineNickname','');onboardName='';nameDraft='';nameSuggestions([]);rankingData=null;rankingRows=[];rankCache.clear();deletionWasPending=true;selectedControl='rankDone';rankingStatus='loading';}}
        function openRecovery(fromOnboard){
            if(!going||!safe()||outbox.status().enabled||outbox.status().deleting)return;
            recovery={screen:'choose',fromOnboard,draft:'',position:0,cursor:0,busy:false,message:''};
            selectedControl=outbox.status().recoveryPending?'later':'enter';
        }
        function finishRecoveryChoice(){
            const fromOnboard=recovery.fromOnboard;
            recovery=null;recoveryTilt=null;
            if(fromOnboard)onboardStep(4);else closeConsent();
        }
        function recoveryBack(){
            if(recovery.screen==='keyboard'){
                recovery.screen='choose';recovery.busy=false;
                recovery.message='';recoveryTilt=null;selectedControl='enter';return;
            }
            if(recovery.screen==='code'){selectedControl=recovery.returnControl;recovery=null;return;}
            finishRecoveryChoice();
        }
        function showRecoveryCode(){
            if(!outbox.token()||!safe())return;
            const view=recovery={screen:'code',message:'checking',code:'',returnControl:'recoveryCode'};
            selectedControl='done';
            outbox.getRecoveryCode((err,code)=>{
                if(recovery!==view)return;
                view.message=err?(err.code==='HTTP_409'?'codeElsewhere':'offline'):'keepCode';
                if(!err)view.code=code;
            });
        }
        function recoveryRequest(view, run){
            if(view.busy)return;
            const epoch=consentEpoch;
            const active=()=>!closed&&going&&safe()&&recovery===view&&view.busy&&consentEpoch===epoch;
            view.busy=true;view.message='checking';
            const complete=message=>{if(active()){view.busy=false;view.message=message;}};
            Promise.resolve(view.hash||probeVin(active)).then(hash=>{
                if(!active())return;
                if(!hash){complete('vehicleError');return;}
                view.hash=hash;
                run(hash,active,complete);
            },()=>complete('vehicleError'));
        }
        function recoveryAction(action){
            if(!going||!safe()||!recovery)return;
            const view=recovery,status=outbox.status();
            if(view.screen==='keyboard'){recoveryKey(view.cursor);return;}
            if(action==='done'||action==='later'){recoveryBack();return;}
            if(status.recoveryPending||view.busy)return;
            if(action==='enter'){
                view.screen='keyboard';view.message='';recoveryTilt=null;return;
            }
            if(action==='startNew'){
                recoveryRequest(view,(hash,active,complete)=>{
                    if(!outbox.enroll(hash,bestModes)){complete('storageError');return;}
                    onboardName='';settings.set('offlineNickname','');finishRecoveryChoice();
                });
            }
            if(action==='restore'&&view.profile){
                if(!outbox.prepareRecovery(view.draft,view.hash)){view.message='storageError';return;}
                onboardName='';view.screen='choose';view.profile=null;
                view.draft='';view.hash=null;selectedControl='later';
                outbox.tick(Date.now());
            }
        }
        function recoveryKey(index){
            const view=recovery,key=recoveryUI.keys[index];
            if(!view||!key||!going||!safe())return;
            view.cursor=index;
            if(key.id==='BACK'){recoveryBack();return;}
            if(view.busy)return;
            if(key.id==='SAVE'){
                if(!recoveryUI.CODE.test(view.draft))return;
                recoveryRequest(view,(hash,active,complete)=>{
                    rankingClient.previewRecovery(view.draft,hash,(err,result)=>{
                        if(!active())return;
                        const profile=!err&&recoveryUI.readProfile(result);
                        if(!profile){complete(err&&err.code==='HTTP_404'?'invalid':'offline');return;}
                        complete('');view.profile=profile;view.screen='found';selectedControl='restore';
                    });
                });
                return;
            }
            view.message='';
            const pos=view.position;
            if(key.id==='LEFT')view.position=Math.max(0,pos-1);
            else if(key.id==='RIGHT')view.position=Math.min(view.draft.length,pos+1);
            else if(key.id==='DEL'&&pos>0){view.draft=view.draft.slice(0,pos-1)+view.draft.slice(pos);view.position--;}
            else if(/^[0-9A-F]$/.test(key.id)&&view.draft.length<32){
                view.draft=view.draft.slice(0,pos)+key.id.toLowerCase()+view.draft.slice(pos);view.position++;
            }
        }
        function applyRecoveredProfile(){
            const profile=outbox.recoveredProfile();
            if(!profile)return;
            profile.records.forEach((record,i)=>{
                bestModes[i]=Math.max(bestModes[i],record);
                settings.set(bestKeys[i],bestModes[i]);
            });
            best=bestModes[game.difficulty];
            settings.set('best',Math.max.apply(null,bestModes));
            settings.set('offlineNickname',profile.nickname);
            if(!outbox.acknowledgeRecovery())return;
            onboardName='';
            if(recovery&&recovery.screen!=='code'){
                finishRecoveryChoice();
                if(going&&safe()){
                    recovery={screen:'code',message:'keepCode',code:profile.code,returnControl:selectedControl};
                    selectedControl='done';
                }
            }
            rankingData=null;rankingRows=[];rankCache.clear();
            if(rankingOpen)loadRanking(rankingMode,true);
        }
        function openName(){if(!outbox.status().enabled)return;editName=true;nameDraft=outbox.status().nameRejected||outbox.status().nickname||String(settings.get('offlineNickname')||'');namePos=nameDraft.length;nameCursor=0;nameShift=false;nameTilt=null;checkName();}
        function nameKey(i){if(!editName||!going||!safe()||!nameKeys[i])return;nameCursor=i;const k=nameKeys[i].id;if(k==='BACK'){editName=false;onboardEditing=false;return;}if(/^SUGGEST/.test(k)){nameDraft=nameKeys[i].label;namePos=nameDraft.length;checkName();return;}if(k==='SAVE'){if(!/^[A-Za-z0-9_-]{3,16}$/.test(nameDraft)||nameCheck==='taken')return;if(onboardEditing){if(/^[A-Za-z0-9_-]{3,16}$/.test(nameDraft)){onboardName=nameDraft;editName=false;onboardEditing=false;}return;}if(outbox.rename(nameDraft,bestModes))editName=false;return;}const next=keyboard.edit(nameDraft,namePos,k,nameShift,outbox.status().originalNickname);const changed=nameDraft!==next.value;nameDraft=next.value;namePos=next.pos;nameShift=next.shift;if(changed)checkName();}
        function showRanking(){if(!rankingData)return;rankingRows=rankingData.boards[MODES[rankingMode]].slice(0,10);rankingStatus='ready';}
        function loadRanking(mode,force){if(outbox.status().deleting)return;if(force&&rankCache.busy)return;rankingMode=mode;rankingError='';if(rankingData)showRanking();else rankingStatus='loading';rankCache.get(outbox.token(),!!force,(err,result)=>{if(closed)return;if(result){rankingData=result;if(result.profile)outbox.rememberOriginal(result.profile.original_nickname);showRanking();}if(err){rankingError=String(err.code||err.message||'NETWORK').slice(0,40);if(!result)rankingStatus='error';}});}
        function selectRankTab(mode){rankingMode=mode;selectedControl='rankTab'+mode;if(rankingData)showRanking();}
        function openRanking(){if(!going||paused||exitDialog||settingsOpen||game.state==='playing')return;rankingOpen=true;selectedControl='rankTab'+game.difficulty;loadRanking(game.difficulty);}
        function closeRanking(){++consentEpoch;deleteOpen=false;editName=false;onboardEditing=false;consentOpen=false;rankingOpen=false;++rankingRequest;selectedControl='play';}
        function openSettings(){if(!going||paused||exitDialog||game.state==='playing')return;settingsOpen=true;selectedControl='mode';}
        function closeSettings(){dropdown=null;settingsOpen=false;selectedControl='play';}
        function openDropdown(kind){dropdown=kind;dropdownIndex=kind==='mode'?game.difficulty:Math.max(0,languageChoices.indexOf(languageChoice));}
        function commitDropdown(index){if(!dropdown||!going||!safe())return;const kind=dropdown;dropdown=null;selectedControl=kind;if(kind==='mode')chooseDifficulty(index);else chooseLanguage(index);}
        function dropdownStart(){return Math.max(0,Math.min(dropdownIndex-2,(dropdown==='mode'?4:languageChoices.length)-6));}
        function backAction(){
            if(!shown()||closed||exiting)return;
            if(recovery){recoveryBack();return;}
            if(deleteOpen){deleteOpen=false;selectedControl='rankDone';return;}
            if(editName){editName=false;onboardEditing=false;return;}
            if(onboarding){++consentEpoch;if(onboarding>1)onboardStep(onboarding-1);return;}
            if(consentOpen){closeConsent();return;}
            if(rankingOpen){closeRanking();return;}
            if(settingsOpen){if(dropdown)dropdown=null;else closeSettings();return;}
            if(exitDialog){exitDialog=false;selectedControl=paused?'resume':'play';return;}
            if(game.state==='playing'&&!paused){pauseRun();return;}
            exitDialog=true;selectedControl='cancel';
        }
        function exitAction(choice){
            if(!exitDialog)return;
            if(choice==='cancel'){exitDialog=false;selectedControl=paused?'resume':'play';return;}
            if(choice!=='exit'||exiting)return;
            exiting=true;exitDialog=false;saveBest();sync();
            Promise.resolve(ui.close('GAME')).catch(e=>{log.warn('close dashboard '+e);exiting=false;exitDialog=true;selectedControl='cancel';sync();});
        }
        function backTilt(value,source){
            if(!value)return;
            const raw=value.frontRotaryEncoderDeflection;
            if(raw===undefined)return;
            const now=Date.now();
            if(source==='renderer')rendererTiltAt=now;
            else if(now-rendererTiltAt<1000)return;
            if(recovery&&recovery.screen==='keyboard'){
                const dir=keyboard.direction(raw);
                if(going&&safe()&&dir&&dir!==recoveryTilt)recovery.cursor=keyboard.move(recovery.cursor,dir,recoveryUI.keys);
                recoveryTilt=dir;return;
            }
            if(editName){const dir=keyboard.direction(raw);if(going&&safe()&&dir&&dir!==nameTilt)nameCursor=keyboard.move(nameCursor,dir,nameKeys);nameTilt=dir;return;}
            nameTilt=null;
            const left=raw===10||raw===11||raw==='10'||raw==='11'||raw==='DREHGEBER_KURZ_LINKS'||raw==='DREHGEBER_LANG_LINKS';
            if(left&&!tiltHeld)backAction();
            tiltHeld=left;
        }
        function sync() {
            const go = !closed && !exiting && shown() && !!safe();
            if (go !== going) {
                going = go;
                last = null; accumulator = 0; frameAt = -Infinity; fpsAt=0; fpsFrames=0; actualFPS=0;
                ctl.enable(go);
                if (ctx.controller && ctx.controller.grab) ctx.controller.grab(go);
                if (!go) { ++consentEpoch;if(recovery){recovery=null;recoveryTilt=null;selectedControl=onboarding?'onNext':rankingOpen?'syncProfile':'play';}deleteOpen=false;saveBest(); if(!safe()){game.reset();paused=false;settingsOpen=false;dropdown=null;editName=false;consentOpen=false;rankingOpen=false;++rankingRequest;exitDialog=false;selectedControl='play';}else pauseRun();  }
            }
            // On unsafe/unknown speed the dashboard remains visible with a warning; gameplay is disabled.
        }
        // Exact BMW CommonTypes.Language via HMI_CID; signal read and subscription.
        // Manifest includes HMIContext so the unit generates its SOME/IP definition.
        // No guessed language from option 6UD; only real signal values are reported.
        try {
            ctx.signals.watch('de.bmw.infotainment.hmi.hmicontext.HMIContext','HMI_CID',{
                currentDisplayLanguage(value){
                    const raw=i18n.raw(value);
                    const next=i18n.langOf(value);
                    headLanguageRaw=raw;
                    headLanguageState=next?'received':'unrecognized';
                    headLanguageSource='HMIContext.currentDisplayLanguage';
                    if(next)systemLanguage=next;
                    log.info('BMW display language raw='+JSON.stringify(raw)+' resolved='+(next||'unknown'));
                    
                }
            },log).then(function(sub){
                if(sub && sub.error) {
                    headLanguageState='error: '+String(sub.error).slice(0,52);
                    log.warn('BMW HMIContext: '+sub.error);
                } else if(sub && !sub.available && !headLanguageRaw){
                    headLanguageState='provider unavailable';
                }
                
            }).catch(function(err){
                headLanguageState='error: '+String(err).slice(0,52);
                log.warn('BMW HMI language: '+err);
                
            });
        } catch(err){
            headLanguageState='error: '+String(err).slice(0,52);
            log.warn('BMW HMI language setup: '+err);
        }
        // One read-only UDS request (22 F190) through BMW's existing TASU link.
        // Never transmit or log the VIN. Unsupported ECUs show a status instead.
        async function probeVin(active) {
            if(!active())return null;
            const quiet={info(){},warn(){},error(){}};let diag;
            try {
                diag = await new Diag(ctx.signals, quiet).init();
                if (!diag.p||!active()) return null;
                const replies = await diag.functional(0x22,[0xF1,0x90],{idleMs:1800,maxMs:9000});
                if(!active())return null;
                const found=findVin(replies);
                const hash=found?identity(found):null;
                replies.clear();
                log.info('VIN read-only probe completed');
                return hash;
            } catch(e) {log.warn('VIN read-only probe unavailable');return null;} finally {if(diag&&diag.p&&typeof diag.p.shutdown==='function')try{await diag.p.shutdown();}catch(e){}}
        }
        checkUpdate(APP_VERSION, function(result) {
            updateState=result;
            log.info('version check: '+(result.checked?(result.available?'update available':'current'):'offline'));
            
        });
        log.info('initial UI language='+systemLanguage+' selected='+languageChoice);
        parked = Parked.watch(safetyCtx, log);
        function chooseDifficulty(index) {
            if (!Number.isInteger(index)||index<0||index>=4)return;
            if (!safe()) {  return; }
            saveBest();
            game.setDifficulty(index);
            best=bestModes[index];
            settings.set('difficulty',game.difficulty);
            
        }
        function chooseLanguage(index) {
            if (!Number.isInteger(index)||index<0||index>=languageChoices.length)return;
            languageChoice=languageChoices[index];
            settings.set('language',languageChoice);
            log.info('language selected: '+languageChoice);
            
        }
        function rotary(value,source){
            const raw=value&&value.frontRotaryEncoderOperation;
            const nRaw=typeof raw==='number'?raw:(typeof raw==='string'&&raw.trim()?Number(raw):NaN);
            if(!Number.isFinite(nRaw))return;
            const n=(Math.floor(nRaw)%65536+65536)%65536,now=Date.now();
            if(source==='renderer')rendererRotaryAt=now;
            const prev=rotaryPosition;rotaryPosition=n;
            if(source==='signals'&&now-rendererRotaryAt<700)return;
            if(prev===null||!going||(game.state==='playing'&&!paused&&!exitDialog))return;
            const diff=((n-prev+32768)%65536)-32768;
            if(!diff||Math.abs(diff)>16)return;
            if(settingsOpen&&dropdown){const count=dropdown==='mode'?4:languageChoices.length;dropdownIndex=(dropdownIndex+(diff>0?1:count-1))%count;return;}
            if(recovery&&recovery.screen==='keyboard'){
                const count=recoveryUI.keys.length;recovery.cursor=(recovery.cursor+diff+count)%count;return;
            }
            if(editName){nameCursor=(nameCursor+diff+nameKeys.length)%nameKeys.length;return;}
            const items=recovery?recoveryUI.buttons(recovery.screen,outbox.status().recoveryPending).map(b=>b.id):deleteOpen?['deleteNo','deleteYes']:onboarding?onboardControls():consentOpen?['consentNo','consentYes']:exitDialog?['cancel','exit']:paused?['resume','menu']:settingsOpen?['mode','language','done']:rankingOpen?(outbox.status().enabled?['rankTab0','rankTab1','rankTab2','rankTab3','editName','deleteAccount'].concat(outbox.token()?['recoveryCode']:[],['refresh','rankDone']):['rankTab0','rankTab1','rankTab2','rankTab3','syncProfile','refresh','rankDone']):(game.state==='over'?['play','overMenu','settings','ranking']:['play','settings','ranking']);
            selectedControl=items[(Math.max(0,items.indexOf(selectedControl))+(diff>0?1:items.length-1))%items.length];
        }
        // Touch areas use the 1600x520 dashboard coordinates.
        function dashboardTouch(x,y){
            sync();
            if(!going)return;
            if(x>=890&&x<=1150&&y>=489&&y<=520&&shown()){backAction();return;}
            if(exitDialog){if(y>=275&&y<=337){if(x>=242&&x<=570)exitAction('cancel');else if(x>=600&&x<=928)exitAction('exit');}return;}
            if(paused){if(y>=275&&y<=337){if(x>=242&&x<=570)pauseAction('resume');else if(x>=600&&x<=928)pauseAction('menu');}return;}
            if(recovery){
                const hit=k=>x>=k.x&&x<k.x+k.w&&y>=k.y&&y<k.y+k.h;
                if(recovery.screen==='keyboard'){
                    const index=recoveryUI.keys.findIndex(hit);if(index>=0)recoveryKey(index);
                }else{
                    const button=recoveryUI.buttons(recovery.screen,outbox.status().recoveryPending).find(hit);
                    if(button)recoveryAction(button.id);
                }
                return;
            }
            if(editName){const i=nameKeys.findIndex(k=>x>=k.x&&x<k.x+k.w&&y>=k.y&&y<k.y+k.h);if(i>=0)nameKey(i);return;}
            if(onboarding){if(onboarding===2&&x>=340&&x<=830&&y>=205&&y<=270){selectedControl='onEdit';onboardAction('onEdit');}else if(y>=342&&y<=408){if(x>=245&&x<425&&onboarding>1)onboardAction('onBack');else if(x>=435&&x<675&&onboarding===3&&!outbox.status().enabled)onboardAction('onSkip');else if(x>=685&&x<=930)onboardAction('onNext');}return;}
            if(deleteOpen){if(y>=275&&y<=337){if(x>=242&&x<=570)deleteOpen=false;else if(x>=600&&x<=928)confirmDelete();}return;}
            if(consentOpen){if(y>=275&&y<=337){if(x>=242&&x<=570)closeConsent();else if(x>=600&&x<=928)enableSync();}return;}
            if(rankingOpen){
                if(y>=70&&y<=103&&x>=353&&x<=478&&outbox.token()){showRecoveryCode();return;}
                if(y>=70&&y<=103&&x>=215&&x<=345&&outbox.status().enabled){openDelete();return;}
                if(y>=64&&y<=103&&x>=720&&x<=965){if(outbox.status().enabled)openName();else openConsent();return;}
                if(y>=113&&y<=151&&x>=235&&x<939){selectRankTab(Math.min(3,Math.floor((x-235)/176)));}
                else if(y>=398&&y<=440&&x>=300&&x<=565){selectedControl='refresh';loadRanking(rankingMode,true);}
                else if(y>=398&&y<=440&&x>=600&&x<=865)closeRanking();
                return;
            }
            if(settingsOpen){
                if(dropdown){if(x>=320&&x<=850&&y>=154&&y<406){const index=dropdownStart()+Math.floor((y-154)/42);if(index<(dropdown==='mode'?4:languageChoices.length))commitDropdown(index);}else if(x>=865&&x<=935&&y>=154&&y<=406){const count=dropdown==='mode'?4:languageChoices.length;dropdownIndex=Math.max(0,Math.min(count-1,dropdownIndex+(y<280?-1:1)));}return;}
                if(x>=320&&x<=850){
                    if(y>=200&&y<=258){selectedControl='mode';openDropdown('mode');}
                    else if(y>=272&&y<=330){selectedControl='language';openDropdown('language');}
                    else if(y>=344&&y<=402)closeSettings();
                }return;
            }
            if(game.state!=='playing'&&x>=1191&&x<=1554&&y>=190&&y<=236){openRanking();return;}
            if(game.state!=='playing'&&x>=1480&&x<=1560&&y>=65&&y<=135){openSettings();return;}
            if(game.state==='over'){
                if(y>=275&&y<=337){if(x>=242&&x<=570){selectedControl='play';game.action();}else if(x>=600&&x<=928)returnToStart();}return;
            }
            if(game.state==='playing'){if(x>=22&&x<1154&&y>=52&&y<473)game.action();return;}
            if(x>=345&&x<=825&&y>=252&&y<=312){selectedControl='play';game.action();}
        }
        if(ctx.onTouch)ctx.onTouch((phase,x,y)=>{if(phase===1)dashboardTouch(x,y);return true;});
        if(ctx.onTap)ctx.onTap(dashboardTouch);
        if(ctx.hideButton)ctx.hideButton('BTN_JUMP');
        ui.onClick('BTN_JUMP', () => { sync(); ctl.barClick(); });
        if (ctx.controller && ctx.controller.onInput) {
            ctx.controller.onInput((value) => { sync(); backTilt(value,'renderer'); rotary(value,'renderer'); ctl.raw(value,'renderer'); });
        }
        ctx.signals.watch('de.bmw.infotainment.controlelements.FrontCCU', '1', {
            statusRotaryEncoderState(value) { sync(); backTilt(value,'signals'); rotary(value,'signals'); ctl.raw(value,'signals'); },
        }, log).then((s) => { if (s.error) log.warn('controller: ' + s.error); });
        if (ui.onFocus) ui.onFocus(sync);
        if (ui.onVisible) ui.onVisible((name,visible) => {
            if(name!=='GAME')return;
            if(!visible){++consentEpoch;recovery=null;recoveryTilt=null;deleteOpen=false;pauseRun();settingsOpen=false;editName=false;consentOpen=false;rankingOpen=false;++rankingRequest;exitDialog=false;tiltHeld=false;}
            else {if(exiting){game.reset();paused=false;selectedControl='play';}exiting=false;last=null;accumulator=0;}
            sync();
        });
        const safetyTimer = setInterval(sync, 100);
        let deletionWasPending=outbox.status().deleting;
        const outboxTimer=setInterval(()=>{if(closed)return;applyRecoveredProfile();if(deletionWasPending&&!outbox.status().deleting){deletionWasPending=false;rankCache.clear();rankingData=null;rankingRows=[];if(rankingOpen)loadRanking(rankingMode,true);}if(outbox.status().deleting)deletionWasPending=true;outbox.capture(bestModes);outbox.tick(Date.now());},1000);
        function stop() {
            if (closed) return;
            closed = true; going = false; ctl.enable(false);
            last = null; accumulator = 0;
            clearInterval(safetyTimer);clearInterval(outboxTimer);outbox.stop();
            if (ctx.controller && ctx.controller.grab) ctx.controller.grab(false);
            saveBest();outbox.capture(bestModes);
        }
        if (ctx.app && ctx.app.on) ctx.app.on('shutdown', stop);
        process.on('exit', stop);
        process.on('SIGTERM', () => { stop(); process.exit(0); });
        process.on('SIGINT', () => { stop(); process.exit(0); });

        ctx.loop('GAME', 8, () => {
            sync();
            if (closed || exiting || !shown()) return;
            const now = Date.now();
            const cv = ctx.canvas(W, H).clear('#000000');
            const pl = cv.place;
            const full = pl && pl.full && pl.w > 0 && pl.h > 0;
            const w = full ? pl.w : W, h = full ? pl.h : H;
            game.resize(WORLD_ASPECT); // Fixed collision/spawn world for both styles and screen sizes.
            if (last !== null && going && !paused && !exitDialog) accumulator += Math.max(0, Math.min((now - last) / 1000, 0.2));
            last = now;
            while (accumulator >= STEP) {
                if (game.state === 'playing' && !paused && !exitDialog) {game.step(STEP);if(game.state==='over')selectedControl='play';}
                accumulator -= STEP;
            }
            saveBest();
            if(!fpsAt)fpsAt=now;
            if(now-fpsAt>=1000){actualFPS=Math.round(fpsFrames*1000/(now-fpsAt));fpsFrames=0;fpsAt=now;}
            // GPU path is paced by renderd at up to 60 Hz; PNG fallback is capped by ctx.loop at 8 Hz.
            if (now - frameAt + 2 < 1000 / 60) return; // Allow 16 ms tick rounding on 60 Hz displays.
            frameAt = now;fpsFrames++;
            tickName();const options={nameCheck,paused,onboarding,onboardName,onboardConsent,rankingRefreshing:rankCache.busy,editName,nameDraft,nameCursor,nameKeys,namePos,nameShift,nameBlink:Math.floor(now/500)%2===0,rankingData,consentOpen,deleteOpen,recovery,canShowRecoveryCode:!!outbox.token(),syncProfile:outbox.status(),settingsOpen,dropdown,dropdownIndex,dropdownStart:dropdownStart(),languageItems:languageChoices.map(k=>k==='auto'?'Auto ('+systemLanguage.toUpperCase()+')':i18n.languageNames[k]||k),bestModes,rankingOpen,rankingMode,rankingRows,rankingStatus,rankingError,exitDialog,selectedControl,languageLabel:languageChoice==='auto'?'Auto ('+systemLanguage.toUpperCase()+')':i18n.languageNames[languageChoice]||languageChoice,parked:!!safe(),fps:actualFPS};
            if(full){
                if(!screenRecorder||screenRecorder.w!==w||screenRecorder.h!==h)screenRecorder=new Recorder(w,h);
                screenRecorder.reset();drawDashboard(screenRecorder,game,w,h,best,t(),updateState,options);
                cv.xf(1,0,0).append(screenRecorder).xf();
            }else drawDashboard(cv,game,w,h,best,t(),updateState,options);
            return ui.image('GAME_GFX', cv);
        });
        
        log.info('Chrome Dino '+APP_VERSION+' Dashboard-only, right-side controls, strict zero speed; GPU 60 Hz target, PNG fallback 8 Hz');
    },
});
